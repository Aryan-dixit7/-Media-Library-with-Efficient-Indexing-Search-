#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define HASH_SIZE 101
#define PAGE_SIZE 5
#define MAX_LINE 1024

// ==========================================
// DATA STRUCTURES
// ==========================================

typedef struct {
    int id;
    char *title;
    char *artist;
    char *genre;
    int year;
    char *filepath;
} MediaItem;

// Linked list node for hash table buckets
typedef struct IndexNode {
    MediaItem *item;
    struct IndexNode *next;
} IndexNode;

// Global Catalog
MediaItem **catalog = NULL;
int catalog_size = 0;
int catalog_capacity = 0;

// Hash Tables for fast lookups
IndexNode *artist_index[HASH_SIZE] = {NULL};
IndexNode *genre_index[HASH_SIZE] = {NULL};

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

// Simple polynomial rolling hash function
unsigned int hash(const char *str) {
    unsigned int hash_val = 0;
    while (*str) {
        hash_val = (hash_val << 5) + *str++;
    }
    return hash_val % HASH_SIZE;
}

// Case-insensitive substring search helper
char *stristr(const char *haystack, const char *needle) {
    if (!*needle) return (char *)haystack;
    for (; *haystack; ++haystack) {
        if (toupper(*haystack) == toupper(*needle)) {
            const char *h = haystack, *n = needle;
            while (*h && *n && toupper(*h) == toupper(*n)) { h++; n++; }
            if (!*n) return (char *)haystack;
        }
    }
    return NULL;
}

// Creates a new string duplicate using dynamic memory
char *create_string(const char *source) {
    char *dest = (char *)malloc(strlen(source) + 1);
    if (dest) strcpy(dest, source);
    return dest;
}

// ==========================================
// CORE OPERATIONS (CO1, CO3, CO4)
// ==========================================

// Adds an item to a hash table bucket (Linked List insertion)
void add_to_index(IndexNode **index_table, const char *key, MediaItem *item) {
    unsigned int h = hash(key);
    IndexNode *new_node = (IndexNode *)malloc(sizeof(IndexNode));
    new_node->item = item;
    new_node->next = index_table[h];
    index_table[h] = new_node;
}

// Creates and registers a new media item
void add_media(int id, const char *title, const char *artist, const char *genre, int year, const char *filepath) {
    // Dynamic resizing of catalog array
    if (catalog_size >= catalog_capacity) {
        catalog_capacity = catalog_capacity == 0 ? 10 : catalog_capacity * 2;
        catalog = (MediaItem **)realloc(catalog, (size_t)catalog_capacity * sizeof(MediaItem *));
    }

    MediaItem *item = (MediaItem *)malloc(sizeof(MediaItem));
    item->id = id;
    item->title = create_string(title);
    item->artist = create_string(artist);
    item->genre = create_string(genre);
    item->year = year;
    item->filepath = create_string(filepath);

    catalog[catalog_size++] = item;

    // Build auxiliary indexes
    add_to_index(artist_index, artist, item);
    add_to_index(genre_index, genre, item);
}

// Custom QuickSort by Year (CO3)
void swap(MediaItem **a, MediaItem **b) {
    MediaItem *temp = *a;
    *a = *b;
    *b = temp;
}

int partition(MediaItem **arr, int low, int high) {
    int pivot = arr[high]->year;
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++) {
        if (arr[j]->year < pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void quicksort_by_year(MediaItem **arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quicksort_by_year(arr, low, pi - 1);
        quicksort_by_year(arr, pi + 1, high);
    }
}

// ==========================================
// SEARCH & DISPLAY
// ==========================================

void print_item(MediaItem *item) {
    printf("[%d] %s by %s | Genre: %s | Year: %d | Path: %s\n", 
           item->id, item->title, item->artist, item->genre, item->year, item->filepath);
}

// Substring search on title using full catalog iteration
void search_by_title(const char *keyword) {
    printf("\n--- Search Results for Title: '%s' ---\n", keyword);
    int found = 0;
    for (int i = 0; i < catalog_size; i++) {
        if (stristr(catalog[i]->title, keyword)) {
            print_item(catalog[i]);
            found++;
        }
    }
    if (!found) printf("No matches found.\n");
}

// Fast exact lookup using Hash Table Index
void search_index(IndexNode **index_table, const char *key) {
    unsigned int h = hash(key);
    IndexNode *current = index_table[h];
    int found = 0;
    
    printf("\n--- Index Lookup for: '%s' ---\n", key);
    while (current != NULL) {
        // Double check against hash collisions
        if (strcasecmp(current->item->artist, key) == 0 || strcasecmp(current->item->genre, key) == 0) {
            print_item(current->item);
            found++;
        }
        current = current->next;
    }
    if (!found) printf("No items found in index.\n");
}

// Paginated view of the catalog
void display_paginated() {
    for (int i = 0; i < catalog_size; i++) {
        print_item(catalog[i]);
        if ((i + 1) % PAGE_SIZE == 0 && (i + 1) < catalog_size) {
            printf("--- Press Enter for next page ---");
            getchar(); 
        }
    }
}

// ==========================================
// FILE I/O & PARSING (CO2)
// ==========================================

void import_csv(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Error: Could not open %s\n", filename);
        return;
    }

    char line[MAX_LINE];
    // Skip header
    fgets(line, MAX_LINE, file);

    while (fgets(line, MAX_LINE, file)) {
        // Strip newline
        line[strcspn(line, "\n")] = 0;
        
        // Parse CSV (id,title,artist,genre,year,filepath)
        char *id_str = strtok(line, ",");
        char *title = strtok(NULL, ",");
        char *artist = strtok(NULL, ",");
        char *genre = strtok(NULL, ",");
        char *year_str = strtok(NULL, ",");
        char *filepath = strtok(NULL, ",");

        if (id_str && title && artist && genre && year_str && filepath) {
            add_media(atoi(id_str), title, artist, genre, atoi(year_str), filepath);
        }
    }
    fclose(file);
    printf("Successfully imported catalog from %s\n", filename);
}

// ==========================================
// MAIN MENU (CO5)
// ==========================================

int main() {
    // Demo data initialization
    add_media(1, "Bohemian Rhapsody", "Queen", "Rock", 1975, "/music/queen/bohemian.mp3");
    add_media(2, "Thriller", "Michael Jackson", "Pop", 1982, "/music/mj/thriller.mp3");
    add_media(3, "Inception", "Hans Zimmer", "Soundtrack", 2010, "/movies/inception.mp4");
    add_media(4, "Hotel California", "Eagles", "Rock", 1976, "/music/eagles/hotel.mp3");

    int choice = 0;
    char buffer[256];

    while (1) {
        printf("\n=== Media Library System ===\n");
        printf("1. Display All (Paginated)\n");
        printf("2. Sort by Year & Display\n");
        printf("3. Search by Title (Substring)\n");
        printf("4. Fast Search by Artist (Index)\n");
        printf("5. Import from CSV\n");
        printf("6. Exit\n");
        printf("Choice: ");
        
        if (scanf("%d", &choice) != 1) break;
        getchar(); // consume newline

        switch (choice) {
            case 1:
                display_paginated();
                break;
            case 2:
                quicksort_by_year(catalog, 0, catalog_size - 1);
                printf("\nSorted by Year:\n");
                display_paginated();
                break;
            case 3:
                printf("Enter title keyword: ");
                fgets(buffer, sizeof(buffer), stdin);
                buffer[strcspn(buffer, "\n")] = 0;
                search_by_title(buffer);
                break;
            case 4:
                printf("Enter artist name: ");
                fgets(buffer, sizeof(buffer), stdin);
                buffer[strcspn(buffer, "\n")] = 0;
                search_index(artist_index, buffer);
                break;
            case 5:
                printf("Enter CSV filename: ");
                fgets(buffer, sizeof(buffer), stdin);
                buffer[strcspn(buffer, "\n")] = 0;
                import_csv(buffer);
                break;
            case 6:
                printf("Exiting system.\n");
                // Note: Proper cleanup (freeing memory) should be done here in production.
                return 0;
            default:
                printf("Invalid choice.\n");
        }
    }
    return 0;
}